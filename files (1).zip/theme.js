// Simple theme mode switcher for light/dark mode
function toggleTheme() {
  document.body.classList.toggle('dark-mode');
}